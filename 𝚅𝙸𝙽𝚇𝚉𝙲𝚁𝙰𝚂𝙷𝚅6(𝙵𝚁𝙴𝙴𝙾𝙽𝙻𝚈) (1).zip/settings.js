const fs = require('fs')

//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6287825584822"
global.ch = 'https://whatsapp.com/channel/0029VbACBJJFsn0kxqSbL703'
global.status = true
//====== [ THEME URL & URL ] ========//
global.thumb = "https://files.catbox.moe/i376h7.jpg"
global.thumbnail = "https://files.catbox.moe/i376h7.jpg"
global.packname = '...........'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'


let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})